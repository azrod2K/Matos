<!-- 
Auteur: David Machado
Date: 18.05.2022
Projet: Matos     -->

<div class="container">
            <div class="row" style="flex-wrap: wrap;  justify-content: center;">
                <div class="card" style="width: 18rem;">
                    <img class="card-img-top" src="assets/img/logo.jpg" alt="Card image cap">
                    <div class="card-body">
                        <h5>macbook pro 15pouce</h5>
                        <p class="card-text">ordinateur portable très puissant</p>
                        <a class="btn btn-primary">Louer</a>
                    </div>
                </div>
            </div>
        </div>