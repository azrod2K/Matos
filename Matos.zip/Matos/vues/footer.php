<!-- 
Auteur: David Machado
Date: 18.05.2022
Projet: Matos     -->

<!-- Footer -->
<footer class="page-footer font-small blue pt-4">
    <!-- Copyright -->
    <div class="footer navbar-dark">© 2022 Copyright : David &
        <a class="lienCfpt" href="https://edu.ge.ch/site/cfpt-informatique/">CFPT-I</a>
    </div>
    <!-- Copyright -->
</footer>
<!-- Footer -->
<script src="https://code.jquery.com/jquery-3.3.1.slim.min.js%22%3E"></script>
<script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.14.3/umd/popper.min.js%22%3E"></script>
<script src="assets/bootstrap/bootstrap-5.1.3-dist/bootstrap-5.1.3-dist/js/bootstrap.min.js"></script>
</body>

</html>